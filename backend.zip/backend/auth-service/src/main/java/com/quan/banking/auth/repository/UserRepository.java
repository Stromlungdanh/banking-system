package com.quan.banking.auth.repository;

import com.quan.banking.auth.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<Users, Long> {
    boolean existsByUsername (String username);
    boolean existsByEmail (String email);
}
