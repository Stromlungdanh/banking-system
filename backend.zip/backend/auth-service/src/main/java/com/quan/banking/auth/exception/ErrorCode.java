package com.quan.banking.auth.exception;

public enum ErrorCode {

}
